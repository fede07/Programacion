#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "menu.h"
#include "alumnos.h"

int main()
{
    char op;


    const char opciones [][TAM_MENU] = {"coimvabrxyq",
                                    "Crear archivo y cargar indice",
                                    "Cargar indice desde el archivo de datos",
                                    "Cargar indice desde archivo indice",
                                    "Mostrar Arbol",
                                    "Ver caracteristicas",
                                    "Alta",
                                    "Baja",
                                    "Regenerar como arbol balanceado",
                                    "Buscar 1000 en archivo",
                                    "Buscar 1000 en indice",
                                    "Salir"};


    do{
        switch(op){
            case 'C':

                pausa("");
                break;

            case 'O':
                pausa("");
                break;

            case 'I':
                pausa("");
                break;

            case 'M':
                pausa("");
                break;

            case 'V':
                pausa("");
                break;

            case 'R':
                pausa("");
                break;

            case 'B':
                pausa("");
                break;

            case 'X':
                pausa("");
                break;


            case 'Y':
                pausa("");
                break;


            default:
                fflush(stdin);
                break;
        }
        op = pedir_opcion(opciones, "----Opciones----", "->");


    }while(op!='Q');

    return 0;
}
